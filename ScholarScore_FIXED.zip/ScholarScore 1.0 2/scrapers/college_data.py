"""
SCHOLARSCORE COLLEGE DATA

This file connects ScholarScore to the official
U.S. Department of Education College Scorecard API.

It searches for colleges and retrieves information such as:
- College name
- City
- State
- Acceptance rate

ScholarScore can later use this information when comparing
a student's profile to colleges.
"""

import requests
import os

from dotenv import load_dotenv

load_dotenv()


# The official College Scorecard API endpoint.
API_URL = "https://api.data.gov/ed/collegescorecard/v1/schools.json"


def search_college(college_name):
    """
    Search for a college using the College Scorecard API.
    """

    # Read our API key from the computer's environment variables.
    api_key = os.getenv("COLLEGE_SCORECARD_API_KEY")

    # Make sure an API key exists.
    if not api_key:
        raise ValueError(
            "COLLEGE_SCORECARD_API_KEY was not found."
        )

    # These are the pieces of information
    # we want to send to the API.
    params = {

        # Our API key.
        "api_key": api_key,

        # Search for the college name entered by the user.
        "school.name": college_name,

        # Tell the API which information we want returned.
        "fields": (
            "id,"
            "school.name,"
            "school.city,"
            "school.state,"
            "latest.admissions.admission_rate.overall"
        ),

        # Limit the number of results.
        "per_page": 10
    }

    # Send the request to the College Scorecard API.
    response = requests.get(
        API_URL,
        params=params,
        timeout=10
    )

    # Stop the program if the request fails.
    response.raise_for_status()

    # Convert the API's JSON response into a Python dictionary.
    data = response.json()

    # Get the list of colleges.
    results = data.get("results", [])

    # Create an empty list that will contain cleaned college data.
    colleges = []

    # Go through every college returned by the API.
    for college in results:

        # Get the acceptance rate.
        acceptance_rate = college.get(
            "latest.admissions.admission_rate.overall"
        )

        # The API gives acceptance rates as decimals.
        # Example:
        # 0.25 = 25%
        if acceptance_rate is not None:
            acceptance_rate = round(
                acceptance_rate * 100,
                1
            )

        # Create a cleaner version of the college data.
        cleaned_college = {
            "id": college.get("id"),
            "name": college.get("school.name"),
            "city": college.get("school.city"),
            "state": college.get("school.state"),
            "acceptance_rate": acceptance_rate
        }

        # Add the college to our list.
        colleges.append(cleaned_college)

    # Send the finished list back to whatever called this function.
    return colleges


# This section runs only when we run this file directly.
if __name__ == "__main__":

    # Ask the student to type a college name.
    college_name = input(
        "Enter a college name: "
    )

    # Search for the college.
    results = search_college(college_name)

    # Check if anything was found.
    if not results:

        print("No colleges found.")

    else:

        # Print every college that was found.
        for college in results:

            print()
            print("----------------------------")

            print(
                "College:",
                college["name"]
            )

            print(
                "Location:",
                college["city"],
                college["state"]
            )

            # Check whether the college reported an acceptance rate.
            if college["acceptance_rate"] is not None:

                print(
                    "Acceptance Rate:",
                    college["acceptance_rate"],
                    "%"
                )

            else:

                print(
                    "Acceptance Rate: Not available"
                )